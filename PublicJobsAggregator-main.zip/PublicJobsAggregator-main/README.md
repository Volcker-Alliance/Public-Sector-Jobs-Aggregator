# PublicJobsAggregator

## Architecture

### Scraping
Python script

### Backend
Node.js

### Frontend
Pug templates

### Database
MySql

## Installation Requirements 
Node.js (16+)<br/> 
Python (3.7+)<br/>
bs4 (4.10+)<br/>
sqlalchemy (1.4+)<br/>
requests (2.27+)<br/>
pytz (2021.3+)<br/>

